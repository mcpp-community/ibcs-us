/*
 * IBCS used to be a kernel module, and is still written that way.
 * This file does what the Linux 2.6.32 include file <linux/fcntl.h>
 * did, but does it by emulating the same functions in user user space.
 *
 * These files are mostly derived / copied from the linux kernel source,
 * and so are covered by the same licence.
 *
 * Author: Russell Stuart <russell+ibcs@stuart.id.au>
 */
#ifndef _IBCS_US_LINUX26_INCLUDE_LINUX_FCNTL_H
#define _IBCS_US_LINUX26_INCLUDE_LINUX_FCNTL_H
#include <bits/types.h>
#include <sys/cdefs.h>

#define	_FCNTL_H			/* We don't want the libc fcntl.h */
#define __USE_LARGEFILE64
#include <bits/fcntl.h>
#include <bits/fcntl-linux.h>

/*
 * AT_FDCWD / AT_EACCESS are gated behind __USE_ATFILE / __USE_GNU in
 * glibc, which aren't set with -ffreestanding.  Define them locally if
 * missing.
 */
#ifndef AT_FDCWD
#define AT_FDCWD	(-100)
#endif
#ifndef AT_EACCESS
#define AT_EACCESS	0x200
#endif

#include <ibcs-us/linux26-compat/linux/mman.h>

#endif
